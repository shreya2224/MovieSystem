package io.egen.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;

import io.egen.api.entity.Movie;
import io.egen.api.exception.MovieNotFound;
import io.egen.api.service.MovieService;

@Controller
@ResponseBody
//@RestController
@RequestMapping(value="/movies")
public class MovieController {
	
	public enum searchParameter {Type, Genre, year, title};
	
	@Autowired
	private MovieService service;
	
	@RequestMapping(method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public List<Movie> findAllMovies()
	{
		return service.findAllMovies();
	}
	
	/*@RequestMapping(value="/{title}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_UTF8_VALUE )
	public Movie findMovies(@PathVariable("title") String movieTitle )
	{
		return service.findMovies(movieTitle);
	}  */
	
	
	
	@RequestMapping(value="/{searchParameter}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_UTF8_VALUE )
	public List<Movie> findMovies(@PathVariable("searchParameter") String moviesearchParameter)
	{
		return service.findMovies(moviesearchParameter);
	}
	
	@RequestMapping(method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_UTF8_VALUE, produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Movie AddNewTitle(@RequestBody Movie newMovie)
	{
		//System.out.println("I am in controller");
		return service.AddNewTitle(newMovie);
	}	
	
	@RequestMapping(value="/{title}",method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_UTF8_VALUE, produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public Movie EditTitle(@PathVariable("title") String title, @RequestBody Movie movTitle) throws MovieNotFound
	{
	    return service.EditTitle(title, movTitle);
	}
	
	@RequestMapping(value="/{title}",method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public void DeleteTitle(@PathVariable("title") String title) throws MovieNotFound
	{
		 service.DeleteTitle(title);
	}
	
}
