package io.egen.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.egen.api.entity.Users;
import io.egen.api.exception.UserAlreadyExists;
import io.egen.api.service.UsersService;

@RestController
@RequestMapping(value="/users")
public class UsersController {
	
	@Autowired
	private UsersService service;
	
	@RequestMapping(method=RequestMethod.GET)
	public List<Users> getUsers()
	{
		return service.getUsers();
	}
	
	@RequestMapping(method=RequestMethod.POST) 
	public Users createUsers(@RequestBody Users newUser) throws UserAlreadyExists
	{
		//System.out.println("I am in Controller");
		return service.createUsers(newUser);
	}
	
	

}
