package io.egen.api.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Table
@Entity
public class Users {

	private String Username;
	
	@Id
	@GenericGenerator(strategy="uuid2", name="useruuid")
	@GeneratedValue(generator="useruuid")
	private String UserId;
	
	@Column(unique=true)
	private String Email;
	
	private final String Role = "User";
	
	private String Password;
	
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getUsername() {
		return Username;
	}
	
	public void setUsername(String username) {
		Username = username;
	}
	
	public String getUserId() {
		return UserId;
	}
	public void setUserId(String userId) {
		UserId = userId;
	}
	
 	 public String getRole() {
		return Role;
	} 
	/*public void setRole(String role) {
		Role = role;
	} */
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
}
