package io.egen.api.exception;

public class MovieNotFound extends RuntimeException{

	
	private static final long serialVersionUID = 3273501034851169866L;
	
	public MovieNotFound(String message)
	{
		super(message);
	}
	
	public MovieNotFound(String message, Throwable cause)
	{
		super(message,cause);
	}

}
