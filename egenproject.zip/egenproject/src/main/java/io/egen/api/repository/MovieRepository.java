package io.egen.api.repository;

import java.util.List;

import io.egen.api.entity.Movie;

public interface MovieRepository {
	
	public List<Movie> findAllMovies();

	//public Movie findMovies(String title);
	public List<Movie> findMovies(String searchParameter);
	
	public Movie AddNewTitle(Movie newMovie);
	
	public Movie EditTitle(Movie movTitle);
	
	public void DeleteTitle(Movie movDelete);
}
