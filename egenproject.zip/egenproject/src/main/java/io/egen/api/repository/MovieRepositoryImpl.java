package io.egen.api.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import io.egen.api.entity.Movie;

@Repository
public class MovieRepositoryImpl implements MovieRepository{
	
	public enum params {Type, Genre, year,title};
	//public enum moviegenre {Drama, Crime, SciFi, Action, Comedy}
	
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public List<Movie> findAllMovies() {
		TypedQuery<Movie> query = em.createQuery("SELECT m from Movie m ORDER BY m.title ASC", Movie.class);
		return query.getResultList();
	}

	
	@Override
	public List<Movie> findMovies(String searchParameter) {
		TypedQuery<Movie> query = em.createQuery("SELECT m FROM Movie m WHERE m.Type=:params OR m.year=:params OR m.title=:params", Movie.class);
		query.setParameter("params", searchParameter);
		return query.getResultList();
		
	}


	@Override
	public Movie AddNewTitle(Movie newMovie) {
		//System.out.println("I am in repository");
		em.persist(newMovie);
		return newMovie;	
		
	}


	@Override
	public Movie EditTitle(Movie movTitle) {
		em.merge(movTitle);
		return movTitle;
	}


	@Override
	public void DeleteTitle(Movie movDelete) {
		em.remove(movDelete);
	}


	/*@Override
	public Movie findMovies(String title) {
		//return em.find(Movie.class, title);
		TypedQuery<Movie> query = em.createNamedQuery("Movie.findByTitle", Movie.class);
		query.setParameter("pTitle", title);
		List<Movie> tmovies = query.getResultList();
		if(tmovies != null && tmovies.size() == 1) {
			return tmovies.get(0);
		}
		else {
			return null;
		}
	} */

	
}
