package io.egen.api.repository;

import java.util.List;

import io.egen.api.entity.Users;

public interface UsersRepository {

	public List <Users> getUsers();
	
	public Users createUsers(Users newUser);
	
	public Users findByEmail(String Email);
}
