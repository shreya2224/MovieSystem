package io.egen.api.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import io.egen.api.entity.Users;

@Repository
public class UsersRepositoryImpl implements UsersRepository{

	@PersistenceContext
	private EntityManager em;

	@Override
	public List<Users> getUsers() {
		TypedQuery<Users> query = em.createQuery("SELECT u FROM Users u ORDER BY u.Username ASC", Users.class);
		return query.getResultList();
	}

	@Override
	public Users createUsers(Users newUser) {
		 em.persist(newUser);
		 return newUser;
	}

	@Override
	public Users findByEmail(String Email) {
		TypedQuery<Users> query = em.createQuery("SELECT u from Users u WHERE u.Email=:pmail", Users.class);
		query.setParameter("pmail", Email);
		List<Users> users = query.getResultList();
		if(users!=null && users.size()==1)
		{
			return users.get(0);
		}
		else
			return null;
	}
	
}
