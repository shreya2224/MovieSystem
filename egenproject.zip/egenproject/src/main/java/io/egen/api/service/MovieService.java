package io.egen.api.service;

import java.util.List;

import io.egen.api.entity.Movie;
import io.egen.api.exception.MovieNotFound;

public interface MovieService {

	public List<Movie> findAllMovies();
	//public Movie findMovies(String title);
	public List<Movie> findMovies(String searchParameter);
	
	public Movie AddNewTitle(Movie newMovie);
	
	public Movie EditTitle(String title, Movie movTitle);
	
	public void DeleteTitle(String title) throws MovieNotFound;
	
}
