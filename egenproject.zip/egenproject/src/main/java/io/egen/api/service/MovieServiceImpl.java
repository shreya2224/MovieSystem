package io.egen.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.egen.api.entity.Movie;
import io.egen.api.exception.MovieNotFound;
import io.egen.api.repository.MovieRepository;

@Service
@Transactional
public class MovieServiceImpl implements MovieService{
	
	@Autowired
	private MovieRepository repository;
	
	@Override
	public List<Movie> findAllMovies() {
		
		return repository.findAllMovies();
	}

	@Override
	public List<Movie> findMovies(String searchParameter) {
		
		
		List<Movie> existing = repository.findMovies(searchParameter);
		if(existing == null)
		{
			throw new MovieNotFound("Movie with " + searchParameter + " not found.");
		}
		
		return  existing;
	}

	@Override
	public Movie AddNewTitle(Movie newMovie) {
		//System.out.println("I am in service layer");
		return repository.AddNewTitle(newMovie);
		
	}

	@Override
	public Movie EditTitle(String title, Movie movTitle) throws MovieNotFound {
		List<Movie> existing = repository.findMovies(title);
		if(existing==null)
		{
			throw new MovieNotFound("Movie with " + title + "not found");
		}
		return repository.EditTitle(movTitle);
	}

	@Override
	public void DeleteTitle(String title) throws MovieNotFound{
		Movie existing = repository.findMovies(title).get(0);
		if(existing == null)
		{
			throw new MovieNotFound("Movie with " + title + "not found");
		}
		repository.DeleteTitle(existing);
	} 
		
	

/*	@Override
	public Movie findMovies(String title) throws MovieNotFound {
		 
		Movie existing = repository.findMovies(title);
		
		if(existing == null)
		{
			throw new MovieNotFound("Movie with title" + title + "not found.");
		}
		
		return existing;
	} */

	

}
