package io.egen.api.service;

import java.util.List;

import io.egen.api.entity.Users;
import io.egen.api.exception.UserAlreadyExists;

public interface UsersService {
	
	public List<Users> getUsers();
	
	public Users createUsers(Users newUser) throws UserAlreadyExists;

}
