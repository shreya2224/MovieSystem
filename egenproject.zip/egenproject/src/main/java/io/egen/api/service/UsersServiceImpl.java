package io.egen.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import io.egen.api.entity.Users;
import io.egen.api.exception.UserAlreadyExists;
import io.egen.api.repository.UsersRepository;


@Service
@Transactional
public class UsersServiceImpl implements UsersService{
	
	
	@Autowired
	private UsersRepository repository;

	@Override
	public List<Users> getUsers() {
		return repository.getUsers();
	}

	@Override
	public Users createUsers(Users newUser) throws UserAlreadyExists {
		//System.out.println("I am in service layer");
		Users existing = repository.findByEmail(newUser.getEmail());
		if(existing!=null)
		{
			throw new UserAlreadyExists();
		}
		return repository.createUsers(newUser);
	}

}
