function moviecollection($scope, $http, orderByFilter){
	$http.get('http://localhost:9999/egenproject/api/movies').
	success(function(data) {
		//window.alert("hello");
		$scope.movies = data;
		
		$scope.propertyName = 'sorting';
		
		$scope.reverse = true;
		//window.alert($scope.reverse);
		$scope.movies = orderByFilter($scope.movies,$scope.propertyName,$scope.reverse);
		
		$scope.sortBy = function(propertyName) {
		      $scope.reverse = (propertyName !== null && $scope.propertyName === propertyName) ? !$scope.reverse : false;
		          
		      $scope.propertyName = propertyName;
		      $scope.movies = orderByFilter($scope.movies, $scope.propertyName, $scope.reverse);
		    }  
		
	});
	
	
	
	
}