function UserCollection($scope, $http){
	
	$scope.PostData = function(){
		window.alert("hello");
		var data = $.param({
			UName : $scope.UserName,
			EMail : $scope.Email,
			PassWd : $scope.Password
		});
		
		var config = {
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
				}
		}
		
		$http.post('http://localhost:9999/egenproject/api/users',data,config).
		success(function (data, config){
			
			$scope.users = data;
		}).error(function(data,config){
			$scope.ResponseDetails = "Data: " + data  + "<hr/>config: "+config;
		});
	};
	
}
